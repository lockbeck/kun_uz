package com.company.enums;

public enum ArticleStatus {
    PUBLISHED,NOT_PUBLISHED
}
