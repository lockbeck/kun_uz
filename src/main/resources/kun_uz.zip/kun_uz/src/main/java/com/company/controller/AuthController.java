package com.company.controller;

import com.company.dto.*;
import com.company.dto.profile.ProfileDTO;
import com.company.service.AuthService;
import com.company.util.HttpHeaderUtil;
import com.company.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<ProfileDTO> login(@RequestBody AuthDTO dto) {
        ProfileDTO profileDTO = authService.login(dto);
        return ResponseEntity.ok(profileDTO);
    }

    @PostMapping("/registration")
    public ResponseEntity<?> registration(@RequestBody RegistrationDTO dto) {
        String profileDTO = authService.registration(dto);
        return ResponseEntity.ok(profileDTO);
    }

    @PostMapping("/phone/verification")
    public ResponseEntity<String> login(@RequestBody VerificationDTO dto) {
        String response = authService.verification(dto);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/resend/{phone}")
    public ResponseEntity<ResponseInfoDTO> resendSms(@PathVariable("phone") String phone) {
        ResponseInfoDTO responseInfoDTO = authService.resendSms(phone);
        return ResponseEntity.ok(responseInfoDTO);
    }

    @GetMapping("/email/verification/{token}")
    public ResponseEntity<String> login(@PathVariable("token") String token) {
        Integer id = JwtUtil.decode(token);
        String response = authService.emailVerification(id);
        return ResponseEntity.ok(response);
    }
    @GetMapping("/resend/email/{email}")
    public ResponseEntity<ResponseInfoDTO> resendEmail(@PathVariable("email") String email) {
        ResponseInfoDTO responseInfoDTO = authService.resendEmail(email);
        return ResponseEntity.ok(responseInfoDTO);
    }



}
