package com.company.enums;

public enum ProfileRole {
    USER,MODERATOR,PUBLISHER,ADMIN
}
