package com.company.enums;

public enum TagStatus {
    ACTIVE,BLOCK
}
