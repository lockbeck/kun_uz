package com.company.repository;

import com.company.entity.AttachEntity;
import org.springframework.data.repository.CrudRepository;

public interface AttachRepository extends CrudRepository<AttachEntity,String> {
}
