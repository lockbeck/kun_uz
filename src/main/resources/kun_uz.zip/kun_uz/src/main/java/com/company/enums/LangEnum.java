package com.company.enums;

public enum LangEnum {
    uz,ru,en
}
