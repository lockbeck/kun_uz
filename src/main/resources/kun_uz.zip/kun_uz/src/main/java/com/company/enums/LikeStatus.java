package com.company.enums;

public enum LikeStatus {
    LIKE,DISLIKE
}
